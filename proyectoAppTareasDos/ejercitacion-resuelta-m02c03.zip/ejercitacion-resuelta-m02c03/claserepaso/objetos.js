let nombre = "ramon"

let persona = {
    nombre: 'jose orellana',
    decirnombre: function () {
        return "mi nombre es " + "" + this.nombre;
    },
}


console.log(persona.decirnombre())