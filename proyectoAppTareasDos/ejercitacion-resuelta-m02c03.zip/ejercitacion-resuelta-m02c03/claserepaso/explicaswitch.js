

let universidad = "UVA"
//UVA UDCA MIT 

switch (universidad) {
    case "UVA":
        console.log("hola elegiste la UVA excelene opcion")
        break;
    case "UDCA" :
        console.log("hola elegiste la UDCA excelene opcion")
        break;
    case "MIT" :
        console.log("hola ud entro al MIT")
        break;
    default:
        console.log("hola elegiste una universidad diferente")
        break;
}