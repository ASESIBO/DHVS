let animales = ["vaca","perro","chivo","gato"]

let tamano = animales.length

console.log(tamano)

for (let index = 0; index < animales.length; index++) 
{
    const element = animales[index];
    console.log(element)
    
}